package spies.cis.uab.edu.tfalib.service;

/**
 * Created by Prakashs on 7/26/15.
 */
public enum ServiceState {
    NOT_CONNECTED, RUNNING, CONNECTED;
}
